#include <boost/interprocess/shared_memory_object.hpp>
#include <boost/interprocess/mapped_region.hpp>
#include <iostream>

using namespace boost::interprocess;

int main() {
    try {
        shared_memory_object::remove("SharedMemory");
        shared_memory_object shm(create_only, "SharedMemory", read_write);
        shm.truncate(sizeof(int));

        mapped_region region(shm, read_write);
        int *shared_int = static_cast<int*>(region.get_address());
        *shared_int = 42;

        std::cout << "Producer wrote: " << *shared_int << std::endl;
    } catch (const interprocess_exception &e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
