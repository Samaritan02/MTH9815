#include <boost/interprocess/shared_memory_object.hpp>
#include <boost/interprocess/mapped_region.hpp>
#include <iostream>

using namespace boost::interprocess;

int main() {
    try {
        shared_memory_object shm(open_only, "SharedMemory", read_only);
        mapped_region region(shm, read_only);

        int *shared_int = static_cast<int*>(region.get_address());
        std::cout << "Consumer read: " << *shared_int << std::endl;
    } catch (const interprocess_exception &e) {
        std::cerr << "Error: " << e.what() << std::endl;
        return 1;
    }
    return 0;
}
