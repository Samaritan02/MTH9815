// Combined test program for BondProductService, IRSwapProductService, and new utility methods
#include <iostream>
#include "products.hpp"
#include "productservice.hpp"

using namespace std;

int main()
{
    // Original test code
    // Create the 10Y treasury note
    date maturityDate(2025, Nov, 16);
    string cusip = "912828M56";
    Bond treasuryBond(cusip, CUSIP, "T", 2.25, maturityDate);

    // Create the 2Y treasury note
    date maturityDate2_old(2017, Nov, 5);
    string cusip2 = "912828TW0";
    Bond treasuryBond2(cusip2, CUSIP, "T", 0.75, maturityDate2_old);

    // Create a BondProductService
    BondProductService *bondProductService = new BondProductService();

    // Add the 10Y note to the BondProductService and retrieve it from the service
    bondProductService->Add(treasuryBond);
    Bond bond = bondProductService->GetData(cusip);
    cout << "CUSIP: " << bond.GetProductId() << " ==> " << bond << endl;

    // Add the 2Y note to the BondProductService and retrieve it from the service
    bondProductService->Add(treasuryBond2);
    bond = bondProductService->GetData(cusip2);
    cout << "CUSIP: " << bond.GetProductId() << " ==> " << bond << endl;

    // Create the Spot 10Y Outright Swap
    date effectiveDate(2015, Nov, 16);
    date terminationDate(2025, Nov, 16);
    string outright10Y = "Spot-Outright-10Y";
    IRSwap outright10YSwap(outright10Y, THIRTY_THREE_SIXTY, THIRTY_THREE_SIXTY, SEMI_ANNUAL, LIBOR, TENOR_3M, effectiveDate, terminationDate, USD, 10, SPOT, OUTRIGHT);

    // Create the IMM 2Y Outright Swap
    date effectiveDate2_old(2015, Dec, 20);
    date terminationDate2_old(2017, Dec, 20);
    string imm2Y = "IMM-Outright-2Y";
    IRSwap imm2YSwap(imm2Y, THIRTY_THREE_SIXTY, THIRTY_THREE_SIXTY, SEMI_ANNUAL, LIBOR, TENOR_3M, effectiveDate2_old, terminationDate2_old, USD, 2, IMM, OUTRIGHT);

    // Create a IRSwapProductService
    IRSwapProductService *swapProductService = new IRSwapProductService();

    // Add the Spot 10Y Outright Swap to the IRSwapProductService and retrieve it from the service
    swapProductService->Add(outright10YSwap);
    IRSwap swap = swapProductService->GetData(outright10Y);
    cout << "Swap: " << swap.GetProductId() << " == > " << swap << endl;

    // Add the IMM 2Y Outright Swap to the IRSwapProductService and retrieve it from the service
    swapProductService->Add(imm2YSwap);
    swap = swapProductService->GetData(imm2Y);
    cout << "Swap: " << swap.GetProductId() << " == > " << swap << endl;

    // New testing code
    // BondProductService testing
    cout << "--- BondProductService Testing ---" << endl;

    // Create bonds
    date maturityDate1(2025, Nov, 16);
    string cusip1 = "912828M56";
    Bond bond1(cusip1, CUSIP, "T", 2.25, maturityDate1);

    date maturityDate2(2027, Nov, 5);
    string cusip2_new = "912828TW0";
    Bond bond2(cusip2_new, CUSIP, "T", 1.75, maturityDate2);

    date maturityDate3(2023, Nov, 15);
    string cusip3 = "912828PZ7";
    Bond bond3(cusip3, CUSIP, "X", 3.50, maturityDate3);

    BondProductService bondService;
    bondService.Add(bond1);
    bondService.Add(bond2);
    bondService.Add(bond3);

    string tickerT = "T";
    vector<Bond> bondsWithTicker = bondService.GetBonds(tickerT);
    cout << "Bonds with ticker 'T':" << endl;
    for (const auto& bond : bondsWithTicker) {
        cout << bond << endl;
    }

    // IRSwapProductService testing
    cout << "--- IRSwapProductService Testing ---" << endl;

    // Create swaps
    date effectiveDate1(2023, Nov, 16);
    date terminationDate1(2028, Nov, 16);
    string swapId1 = "Swap-5Y";
    IRSwap swap1(swapId1, THIRTY_THREE_SIXTY, THIRTY_THREE_SIXTY, ANNUAL, LIBOR, TENOR_3M, effectiveDate1, terminationDate1, USD, 5, SPOT, OUTRIGHT);

    date effectiveDate2(2023, Nov, 16);
    date terminationDate2(2033, Nov, 16);
    string swapId2 = "Swap-10Y";
    IRSwap swap2(swapId2, THIRTY_THREE_SIXTY, THIRTY_THREE_SIXTY, SEMI_ANNUAL, LIBOR, TENOR_6M, effectiveDate2, terminationDate2, USD, 10, IMM, OUTRIGHT);

    date effectiveDate3(2023, Nov, 16);
    date terminationDate3(2026, Nov, 16);
    string swapId3 = "Swap-3Y";
    IRSwap swap3(swapId3, THIRTY_THREE_SIXTY, THIRTY_THREE_SIXTY, QUARTERLY, LIBOR, TENOR_3M, effectiveDate3, terminationDate3, USD, 3, SPOT, FLY);

    IRSwapProductService swapService;
    swapService.Add(swap1);
    swapService.Add(swap2);
    swapService.Add(swap3);

    // Test utility methods
    vector<IRSwap> swapsWithConvention = swapService.GetSwaps(THIRTY_THREE_SIXTY);
    cout << "Swaps with fixed leg day count convention THIRTY_THREE_SIXTY:" << endl;
    for (const auto& swap : swapsWithConvention) {
        cout << swap << endl;
    }

    vector<IRSwap> swapsWithFreq = swapService.GetSwaps(ANNUAL);
    cout << "Swaps with fixed leg payment frequency ANNUAL:" << endl;
    for (const auto& swap : swapsWithFreq) {
        cout << swap << endl;
    }

    vector<IRSwap> swapsWithIndex = swapService.GetSwaps(LIBOR);
    cout << "Swaps with floating index LIBOR:" << endl;
    for (const auto& swap : swapsWithIndex) {
        cout << swap << endl;
    }

    vector<IRSwap> swapsGreaterThan5Y = swapService.GetSwapsGreaterThan(5);
    cout << "Swaps with term greater than 5 years:" << endl;
    for (const auto& swap : swapsGreaterThan5Y) {
        cout << swap << endl;
    }

    vector<IRSwap> swapsLessThan5Y = swapService.GetSwapsLessThan(5);
    cout << "Swaps with term less than 5 years:" << endl;
    for (const auto& swap : swapsLessThan5Y) {
        cout << swap << endl;
    }

    vector<IRSwap> swapsWithType = swapService.GetSwaps(OUTRIGHT);
    cout << "Swaps with type OUTRIGHT:" << endl;
    for (const auto& swap : swapsWithType) {
        cout << swap << endl;
    }

    vector<IRSwap> swapsWithLegType = swapService.GetSwaps(SPOT);
    cout << "Swaps with swap leg type SPOT:" << endl;
    for (const auto& swap : swapsWithLegType) {
        cout << swap << endl;
    }

    return 0;
}
